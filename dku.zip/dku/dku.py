# import tkinter as tk
# from tkinter import messagebox
# import random
# import time

# class SudokuGame:
#     def __init__(self, board=None):
#         if board is None:
#             board = [[0] * 9 for _ in range(9)]
#         self.board = board
#         self.original_board = [row[:] for row in board]
#         self.solution_board = [row[:] for row in board]
#         self.solve_board()

#     def check_board(self):
#         for i in range(9):
#             row = set()
#             col = set()
#             block = set()
#             row_cube = 3 * (i // 3)
#             col_cube = 3 * (i % 3)
#             for j in range(9):
#                 if self.board[i][j] != 0 and self.board[i][j] in row:
#                     return False
#                 row.add(self.board[i][j])
#                 if self.board[j][i] != 0 and self.board[j][i] in col:
#                     return False
#                 col.add(self.board[j][i])
#                 rc = row_cube + j // 3
#                 cc = col_cube + j % 3
#                 if self.board[rc][cc] != 0 and self.board[rc][cc] in block:
#                     return False
#                 block.add(self.board[rc][cc])
#         return True
    
#     def find_empty(self):
#         for i in range(9):
#             for j in range(9):
#                 if self.board[i][j] == 0:
#                     return i, j
#         return None
    
#     def solve(self):
#         find = self.find_empty()
#         if not find:
#             return True
#         else:
#             row, col = find
#         for i in range(1, 10):
#             self.board[row][col] = i
#             if self.check_board():
#                 if self.solve():
#                     return True
#             self.board[row][col] = 0
#         return False
    
#     def solve_board(self):
#         self.board = [row[:] for row in self.original_board]
#         self.solve()
#         self.solution_board = [row[:] for row in self.board]
#         self.board = [row[:] for row in self.original_board]

# class SudokuGUI:
#     def __init__(self, root):
#         self.root = root
#         self.root.title("Sudoku")
#         self.entries = [[None for _ in range(9)] for _ in range(9)]
#         self.moves = []  # Stack to store moves for undo functionality
#         self.difficulty = tk.StringVar(value="Easy")
#         self.create_difficulty_menu()
#         self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
#         self.start_time = time.time()
#         self.timer_label = tk.Label(self.root, text="Time: 00:00")
#         self.timer_label.grid(row=11, column=0, columnspan=9)
#         self.update_timer()
#         self.create_grid()
#         self.create_buttons()
#         self.configure_grid()

#     def create_grid(self):
#         self.canvas = tk.Canvas(self.root, width=450, height=450)
#         self.canvas.grid(row=0, column=0, columnspan=9, rowspan=9)
        
#         # Draw thicker lines for the main grid
#         for i in range(10):
#             line_thickness = 3 if i % 3 == 0 else 1
#             self.canvas.create_line(0, i*50, 450, i*50, width=line_thickness)
#             self.canvas.create_line(i*50, 0, i*50, 450, width=line_thickness)
        
#         for i in range(9):
#             for j in range(9):
#                 entry = tk.Entry(self.root, width=5, justify='center', font=('Arial', 12))
#                 entry.place(x=j*50 + 1, y=i*50 + 1, width=48, height=48)
#                 if self.game.original_board[i][j] != 0:
#                     entry.insert(0, str(self.game.original_board[i][j]))
#                     entry.config(state='disabled', disabledbackground='#D3D3D3')
#                 else:
#                     entry.bind('<KeyRelease>', self.record_move)
#                 self.entries[i][j] = entry

#     def create_buttons(self):
#         solve_button = tk.Button(self.root, text="Solve", command=self.solve)
#         solve_button.grid(row=10, column=0, columnspan=2, sticky='nsew')
#         clear_button = tk.Button(self.root, text="Clear", command=self.clear)
#         clear_button.grid(row=10, column=2, columnspan=2, sticky='nsew')
#         hint_button = tk.Button(self.root, text="Hint", command=self.hint)
#         hint_button.grid(row=10, column=4, columnspan=2, sticky='nsew')
#         undo_button = tk.Button(self.root, text="Undo", command=self.undo)
#         undo_button.grid(row=10, column=6, columnspan=3, sticky='nsew')

#     def configure_grid(self):
#         for i in range(9):
#             self.root.grid_rowconfigure(i, weight=1)
#             self.root.grid_columnconfigure(i, weight=1)
#         self.root.grid_rowconfigure(10, weight=1)
#         self.root.grid_rowconfigure(11, weight=1)

#     def create_difficulty_menu(self):
#         menu = tk.Menu(self.root)
#         self.root.config(menu=menu)
#         difficulty_menu = tk.Menu(menu, tearoff=0)
#         menu.add_cascade(label="Difficulty", menu=difficulty_menu)
#         difficulty_menu.add_radiobutton(label="Easy", variable=self.difficulty, command=self.change_difficulty)
#         difficulty_menu.add_radiobutton(label="Medium", variable=self.difficulty, command=self.change_difficulty)
#         difficulty_menu.add_radiobutton(label="Hard", variable=self.difficulty, command=self.change_difficulty)

#     def change_difficulty(self):
#         self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
#         self.update_grid()

#     def record_move(self, event):
#         widget = event.widget
#         for i in range(9):
#             for j in range(9):
#                 if self.entries[i][j] == widget:
#                     previous_value = self.entries[i][j].get()
#                     if previous_value == '':
#                         previous_value = None
#                     self.moves.append((i, j, previous_value))
#                     return

#     def undo(self):
#         if self.moves:
#             i, j, value = self.moves.pop()
#             self.entries[i][j].config(state='normal')
#             self.entries[i][j].delete(0, tk.END)
#             if value is not None:
#                 self.entries[i][j].insert(0, value)
#             else:
#                 self.entries[i][j].config(bg='white')

#     def solve(self):
#         if not self.game.solve():
#             messagebox.showerror("Error", "No solution exists!")
#         else:
#             for i in range(9):
#                 for j in range(9):
#                     self.entries[i][j].delete(0, tk.END)
#                     self.entries[i][j].insert(0, str(self.game.board[i][j]))
#             messagebox.showinfo("Solved", "The puzzle is solved!")
#             self.stop_timer()
#             self.shuffle_board()

#     def clear(self):
#         for i in range(9):
#             for j in range(9):
#                 if self.game.original_board[i][j] == 0:
#                     self.entries[i][j].delete(0, tk.END)
#         self.moves.clear()
#         self.start_time = time.time()
#         self.update_timer()

#     def hint(self):
#         empty_cells = [(i, j) for i in range(9) for j in range(9) if self.entries[i][j].get() == ""]
#         if empty_cells:
#             i, j = random.choice(empty_cells)
#             previous_value = self.entries[i][j].get()
#             self.entries[i][j].insert(0, str(self.game.solution_board[i][j]))
#             self.entries[i][j].config(state='disabled', disabledbackground='#D3D3D3')
#             self.moves.append((i, j, previous_value))
        
#             if not any(self.entries[i][j].get() == "" for i in range(9) for j in range(9)):
#                 if self.game.check_board():
#                     messagebox.showinfo("Congratulations", "You solved the puzzle!")
#                 else:
#                     messagebox.showinfo("Incorrect", "The puzzle is not solved correctly.")
#                 self.shuffle_board()
#         else:
#             messagebox.showinfo("No Empty Spaces", "All spaces are filled!")

#     def generate_sudoku(self, difficulty):
#         # Generate a complete, valid Sudoku board
#         board = [[0]*9 for _ in range(9)]
#         self.solve_from_empty(board)

#         # Remove some numbers to create the puzzle based on difficulty
#         if difficulty == "Easy":
#             remove_count = 40
#         elif difficulty == "Medium":
#             remove_count = 50
#         else:  # Hard
#             remove_count = 60

#         for _ in range(remove_count):
#             i = random.randint(0, 8)
#             j = random.randint(0, 8)
#             while board[i][j] == 0:
#                 i = random.randint(0, 8)
#                 j = random.randint(0, 8)
#             board[i][j] = 0

#         self.shuffle_board_numbers(board)
#         self.randomize_board(board)
#         return board

#     def solve_from_empty(self, board):
#         temp_game = SudokuGame(board)
#         temp_game.solve()
#         for i in range(9):
#             for j in range(9):
#                 board[i][j] = temp_game.board[i][j]

#     def shuffle_board_numbers(self, board):
#         numbers = list(range(1, 10))
#         random.shuffle(numbers)
#         number_map = {i: numbers[i - 1] for i in range(1, 10)}
#         for i in range(9):
#             for j in range(9):
#                 if board[i][j] != 0:
#                     board[i][j] = number_map[board[i][j]]

#     def randomize_board(self, board):
#         # Perform random row swaps within blocks
#         for _ in range(10):
#             block_row = random.randint(0, 2) * 3
#             row1 = block_row + random.randint(0, 2)
#             row2 = block_row + random.randint(0, 2)
#             if row1 != row2:
#                 board[row1], board[row2] = board[row2], board[row1]

#         # Perform random column swaps within blocks
#         for _ in range(10):
#             block_col = random.randint(0, 2) * 3
#             col1 = block_col + random.randint(0, 2)
#             col2 = block_col + random.randint(0, 2)
#             if col1 != col2:
#                 for row in board:
#                     row[col1], row[col2] = row[col2], row[col1]

#         # Perform random block swaps (row and column)
#         for _ in range(10):
#             block1 = random.randint(0, 2)
#             block2 = random.randint(0, 2)
#             if block1 != block2:
#                 for i in range(3):
#                     board[block1 * 3 + i], board[block2 * 3 + i] = board[block2 * 3 + i], board[block1 * 3 + i]

#         for _ in range(10):
#             block1 = random.randint(0, 2)
#             block2 = random.randint(0, 2)
#             if block1 != block2:
#                 for row in board:
#                     for i in range(3):
#                         row[block1 * 3 + i], row[block2 * 3 + i] = row[block2 * 3 + i], row[block1 * 3 + i]

#     def shuffle_board(self):
#         self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
#         self.moves.clear()
#         self.start_time = time.time()
#         self.update_grid()

#     def update_grid(self):
#         for i in range(9):
#             for j in range(9):
#                 self.entries[i][j].config(state='normal')
#                 self.entries[i][j].delete(0, tk.END)
#                 if self.game.original_board[i][j] != 0:
#                     self.entries[i][j].insert(0, str(self.game.original_board[i][j]))
#                     self.entries[i][j].config(state='disabled', disabledbackground='#D3D3D3')
#                 else:
#                     self.entries[i][j].config(bg='white')

#     def update_timer(self):
#         elapsed_time = time.time() - self.start_time
#         minutes, seconds = divmod(int(elapsed_time), 60)
#         self.timer_label.config(text=f"Time: {minutes:02}:{seconds:02}")
#         self.timer = self.root.after(1000, self.update_timer)

#     def stop_timer(self):
#         self.root.after_cancel(self.timer)

# if __name__ == "__main__":
#     root = tk.Tk()
#     game = SudokuGUI(root)
#     root.mainloop()
# import tkinter as tk
# from tkinter import messagebox
# import random
# import time

# class SudokuGame:
#     def __init__(self, board=None):
#         if board is None:
#             board = [[0] * 9 for _ in range(9)]
#         self.board = board
#         self.original_board = [row[:] for row in board]
#         self.solution_board = [row[:] for row in board]
#         self.solve_board()

#     def check_board(self):
#         for i in range(9):
#             row = set()
#             col = set()
#             block = set()
#             row_cube = 3 * (i // 3)
#             col_cube = 3 * (i % 3)
#             for j in range(9):
#                 if self.board[i][j] != 0 and self.board[i][j] in row:
#                     return False
#                 row.add(self.board[i][j])
#                 if self.board[j][i] != 0 and self.board[j][i] in col:
#                     return False
#                 col.add(self.board[j][i])
#                 rc = row_cube + j // 3
#                 cc = col_cube + j % 3
#                 if self.board[rc][cc] != 0 and self.board[rc][cc] in block:
#                     return False
#                 block.add(self.board[rc][cc])
#         return True
    
#     def find_empty(self):
#         for i in range(9):
#             for j in range(9):
#                 if self.board[i][j] == 0:
#                     return i, j
#         return None
    
#     def solve(self):
#         find = self.find_empty()
#         if not find:
#             return True
#         else:
#             row, col = find
#         for i in range(1, 10):
#             self.board[row][col] = i
#             if self.check_board():
#                 if self.solve():
#                     return True
#             self.board[row][col] = 0
#         return False
    
#     def solve_board(self):
#         self.board = [row[:] for row in self.original_board]
#         self.solve()
#         self.solution_board = [row[:] for row in self.board]
#         self.board = [row[:] for row in self.original_board]

# class SudokuGUI:
#     def __init__(self, root):
#         self.root = root
#         self.root.title("Sudoku")
#         self.entries = [[None for _ in range(9)] for _ in range(9)]
#         self.moves = []  # Stack to store moves for undo functionality
#         self.difficulty = tk.StringVar(value="Easy")
#         self.create_difficulty_menu()
#         self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
#         self.start_time = time.time()
#         self.timer_label = tk.Label(self.root, text="Time: 00:00")
#         self.timer_label.grid(row=11, column=0, columnspan=9)
#         self.update_timer()
#         self.canvas = tk.Canvas(self.root)
#         self.canvas.grid(row=0, column=0, rowspan=9, columnspan=9, sticky='nsew')
#         self.create_grid()
#         self.create_buttons()
#         self.configure_grid()
#         self.root.bind("<Configure>", self.on_resize)

#     def create_grid(self):
#         self.entries = [[None for _ in range(9)] for _ in range(9)]
#         for i in range(9):
#             for j in range(9):
#                 entry = tk.Entry(self.root, width=5, justify='center', font=('Arial', 12))
#                 entry.grid(row=i, column=j, padx=1, pady=1, sticky='nsew')
#                 if self.game.original_board[i][j] != 0:
#                     entry.insert(0, str(self.game.original_board[i][j]))
#                     entry.config(state='disabled', disabledbackground='#D3D3D3')
#                 else:
#                     entry.bind('<KeyRelease>', self.record_move)
#                 self.entries[i][j] = entry
#         self.draw_grid_lines()

#     def draw_grid_lines(self):
#         self.canvas.delete("grid_line")
#         width = self.canvas.winfo_width()
#         height = self.canvas.winfo_height()
#         cell_width = width / 9
#         cell_height = height / 9

#         for i in range(10):
#             line_width = 2 if i % 3 == 0 else 1
#             self.canvas.create_line(i * cell_width, 0, i * cell_width, height, width=line_width, tags="grid_line")
#             self.canvas.create_line(0, i * cell_height, width, i * cell_height, width=line_width, tags="grid_line")

#     def create_buttons(self):
#         solve_button = tk.Button(self.root, text="Solve", command=self.solve)
#         solve_button.grid(row=10, column=0, columnspan=2, sticky='nsew')
#         clear_button = tk.Button(self.root, text="Clear", command=self.clear)
#         clear_button.grid(row=10, column=2, columnspan=2, sticky='nsew')
#         hint_button = tk.Button(self.root, text="Hint", command=self.hint)
#         hint_button.grid(row=10, column=4, columnspan=2, sticky='nsew')
#         undo_button = tk.Button(self.root, text="Undo", command=self.undo)
#         undo_button.grid(row=10, column=6, columnspan=3, sticky='nsew')

#     def configure_grid(self):
#         for i in range(9):
#             self.root.grid_rowconfigure(i, weight=1)
#             self.root.grid_columnconfigure(i, weight=1)
#         self.root.grid_rowconfigure(10, weight=1)
#         self.root.grid_rowconfigure(11, weight=1)

#     def create_difficulty_menu(self):
#         menu = tk.Menu(self.root)
#         self.root.config(menu=menu)
#         difficulty_menu = tk.Menu(menu, tearoff=0)
#         menu.add_cascade(label="Difficulty", menu=difficulty_menu)
#         difficulty_menu.add_radiobutton(label="Easy", variable=self.difficulty, command=self.change_difficulty)
#         difficulty_menu.add_radiobutton(label="Medium", variable=self.difficulty, command=self.change_difficulty)
#         difficulty_menu.add_radiobutton(label="Hard", variable=self.difficulty, command=self.change_difficulty)

#     def change_difficulty(self):
#         self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
#         self.update_grid()

#     def record_move(self, event):
#         widget = event.widget
#         for i in range(9):
#             for j in range(9):
#                 if self.entries[i][j] == widget:
#                     previous_value = self.entries[i][j].get()
#                     if previous_value == '':
#                         previous_value = None
#                     self.moves.append((i, j, previous_value))
#                     return

#     def undo(self):
#         if self.moves:
#             i, j, value = self.moves.pop()
#             self.entries[i][j].config(state='normal')
#             self.entries[i][j].delete(0, tk.END)
#             if value is not None:
#                 self.entries[i][j].insert(0, value)
#             else:
#                 self.entries[i][j].config(bg='white')

#     def solve(self):
#         if not self.game.solve():
#             messagebox.showerror("Error", "No solution exists!")
#         else:
#             for i in range(9):
#                 for j in range(9):
#                     self.entries[i][j].delete(0, tk.END)
#                     self.entries[i][j].insert(0, str(self.game.board[i][j]))
#             messagebox.showinfo("Solved", "The puzzle is solved!")
#             self.stop_timer()
#             self.shuffle_board()

#     def clear(self):
#         for i in range(9):
#             for j in range(9):
#                 if self.game.original_board[i][j] == 0:
#                     self.entries[i][j].delete(0, tk.END)
#         self.moves.clear()
#         self.start_time = time.time()
#         self.update_timer()

#     def hint(self):
#         empty_cells = [(i, j) for i in range(9) for j in range(9) if self.entries[i][j].get() == ""]
#         if empty_cells:
#             i, j = random.choice(empty_cells)
#             previous_value = self.entries[i][j].get()
#             self.entries[i][j].insert(0, str(self.game.solution_board[i][j]))
#             self.entries[i][j].config(state='disabled', disabledbackground='#D3D3D3')
#             self.moves.append((i, j, previous_value))
        
#             if not any(self.entries[i][j].get() == "" for i in range(9) for j in range(9)):
#                 if self.game.check_board():
#                     messagebox.showinfo("Congratulations", "You solved the puzzle!")
#                 else:
#                     messagebox.showinfo("Incorrect", "The puzzle is not solved correctly.")
#                 self.shuffle_board()
#         else:
#             messagebox.showinfo("No Empty Spaces", "All spaces are filled!")

#     def generate_sudoku(self, difficulty):
#         # Generate a complete, valid Sudoku board
#         board = [[0]*9 for _ in range(9)]
#         self.solve_from_empty(board)

#         # Remove some numbers to create the puzzle based on difficulty
#         if difficulty == "Easy":
#             remove_count = 40
#         elif difficulty == "Medium":
#             remove_count = 50
#         else:  # Hard
#             remove_count = 60

#         for _ in range(remove_count):
#             i = random.randint(0, 8)
#             j = random.randint(0, 8)
#             while board[i][j] == 0:
#                 i = random.randint(0, 8)
#                 j = random.randint(0, 8)
#             board[i][j] = 0

#         self.shuffle_board_numbers(board)
#         self.randomize_board(board)
#         return board

#     def solve_from_empty(self, board):
#         temp_game = SudokuGame(board)
#         temp_game.solve()
#         for i in range(9):
#             for j in range(9):
#                 board[i][j] = temp_game.board[i][j]

#     def shuffle_board_numbers(self, board):
#         numbers = list(range(1, 10))
#         random.shuffle(numbers)
#         number_map = {i: numbers[i - 1] for i in range(1, 10)}
#         for i in range(9):
#             for j in range(9):
#                 if board[i][j] != 0:
#                     board[i][j] = number_map[board[i][j]]

#     def randomize_board(self, board):
#         # Perform random row swaps within blocks
#         for _ in range(10):
#             block_row = random.randint(0, 2) * 3
#             row1 = block_row + random.randint(0, 2)
#             row2 = block_row + random.randint(0, 2)
#             if row1 != row2:
#                 board[row1], board[row2] = board[row2], board[row1]

#         # Perform random column swaps within blocks
#         for _ in range(10):
#             block_col = random.randint(0, 2) * 3
#             col1 = block_col + random.randint(0, 2)
#             col2 = block_col + random.randint(0, 2)
#             if col1 != col2:
#                 for row in board:
#                     row[col1], row[col2] = row[col2], row[col1]

#         # Perform random block swaps (row and column)
#         for _ in range(10):
#             block1 = random.randint(0, 2)
#             block2 = random.randint(0, 2)
#             if block1 != block2:
#                 for i in range(3):
#                     board[block1 * 3 + i], board[block2 * 3 + i] = board[block2 * 3 + i], board[block1 * 3 + i]

#         for _ in range(10):
#             block1 = random.randint(0, 2)
#             block2 = random.randint(0, 2)
#             if block1 != block2:
#                 for row in board:
#                     for i in range(3):
#                         row[block1 * 3 + i], row[block2 * 3 + i] = row[block2 * 3 + i], row[block1 * 3 + i]

#     def shuffle_board(self):
#         self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
#         self.moves.clear()
#         self.start_time = time.time()
#         self.update_grid()

#     def update_grid(self):
#         for i in range(9):
#             for j in range(9):
#                 self.entries[i][j].config(state='normal')
#                 self.entries[i][j].delete(0, tk.END)
#                 if self.game.original_board[i][j] != 0:
#                     self.entries[i][j].insert(0, str(self.game.original_board[i][j]))
#                     self.entries[i][j].config(state='disabled', disabledbackground='#D3D3D3')
#                 else:
#                     self.entries[i][j].config(bg='white')

#     def update_timer(self):
#         elapsed_time = time.time() - self.start_time
#         minutes, seconds = divmod(int(elapsed_time), 60)
#         self.timer_label.config(text=f"Time: {minutes:02}:{seconds:02}")
#         self.timer = self.root.after(1000, self.update_timer)

#     def stop_timer(self):
#         self.root.after_cancel(self.timer)

#     def on_resize(self, event):
#         self.draw_grid_lines()

# if __name__ == "__main__":
#     root = tk.Tk()
#     game = SudokuGUI(root)
#     root.mainloop()

import tkinter as tk
from tkinter import messagebox
import random
import time
import os

class SudokuGame:
    def __init__(self, board=None):
        if board is None:
            board = [[0] * 9 for _ in range(9)]
        self.board = board
        self.original_board = [row[:] for row in board]
        self.solution_board = [row[:] for row in board]
        self.solve_board()

    def check_board(self):
        for i in range(9):
            row = set()
            col = set()
            block = set()
            row_cube = 3 * (i // 3)
            col_cube = 3 * (i % 3)
            for j in range(9):
                if self.board[i][j] != 0 and self.board[i][j] in row:
                    return False
                row.add(self.board[i][j])
                if self.board[j][i] != 0 and self.board[j][i] in col:
                    return False
                col.add(self.board[j][i])
                rc = row_cube + j // 3
                cc = col_cube + j % 3
                if self.board[rc][cc] != 0 and self.board[rc][cc] in block:
                    return False
                block.add(self.board[rc][cc])
        return True
    
    def find_empty(self):
        for i in range(9):
            for j in range(9):
                if self.board[i][j] == 0:
                    return i, j
        return None
    
    def solve(self):
        find = self.find_empty()
        if not find:
            return True
        else:
            row, col = find
        for i in range(1, 10):
            self.board[row][col] = i
            if self.check_board():
                if self.solve():
                    return True
            self.board[row][col] = 0
        return False
    
    def solve_board(self):
        self.board = [row[:] for row in self.original_board]
        self.solve()
        self.solution_board = [row[:] for row in self.board]
        self.board = [row[:] for row in self.original_board]

class SudokuGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Sudoku")
        self.entries = [[None for _ in range(9)] for _ in range(9)]
        self.moves = []  # Stack to store moves for undo functionality
        self.difficulty = tk.StringVar(value="Easy")
        self.best_time = self.load_best_time()
        self.create_difficulty_menu()
        self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
        self.start_time = time.time()
        self.timer_label = tk.Label(self.root, text="Time: 00:00")
        self.timer_label.grid(row=11, column=0, columnspan=9)
        self.update_timer()
        self.canvas = tk.Canvas(self.root)
        self.canvas.grid(row=0, column=0, rowspan=9, columnspan=9, sticky='nsew')
        self.create_grid()
        self.create_buttons()
        self.configure_grid()
        self.root.bind("<Configure>", self.on_resize)

    def create_grid(self):
        self.entries = [[None for _ in range(9)] for _ in range(9)]
        for i in range(9):
            for j in range(9):
                entry = tk.Entry(self.root, width=5, justify='center', font=('Arial', 12))
                entry.grid(row=i, column=j, padx=1, pady=1, sticky='nsew')
                if self.game.original_board[i][j] != 0:
                    entry.insert(0, str(self.game.original_board[i][j]))
                    entry.config(state='disabled', disabledbackground='#D3D3D3')
                else:
                    entry.bind('<KeyRelease>', self.record_move)
                self.entries[i][j] = entry
        self.draw_grid_lines()

    def draw_grid_lines(self):
        self.canvas.delete("grid_line")
        width = self.canvas.winfo_width()
        height = self.canvas.winfo_height()
        cell_width = width / 9
        cell_height = height / 9

        for i in range(10):
            line_width = 2 if i % 3 == 0 else 1
            self.canvas.create_line(i * cell_width, 0, i * cell_width, height, width=line_width, tags="grid_line")
            self.canvas.create_line(0, i * cell_height, width, i * cell_height, width=line_width, tags="grid_line")

    def create_buttons(self):
        solve_button = tk.Button(self.root, text="Solve", command=self.solve)
        solve_button.grid(row=10, column=0, columnspan=2, sticky='nsew')
        clear_button = tk.Button(self.root, text="Clear", command=self.clear)
        clear_button.grid(row=10, column=2, columnspan=2, sticky='nsew')
        hint_button = tk.Button(self.root, text="Hint", command=self.hint)
        hint_button.grid(row=10, column=4, columnspan=2, sticky='nsew')
        undo_button = tk.Button(self.root, text="Undo", command=self.undo)
        undo_button.grid(row=10, column=6, columnspan=3, sticky='nsew')
        history_button = tk.Button(self.root, text="History", command=self.show_history)
        history_button.grid(row=11, column=6, columnspan=3, sticky='nsew')

    def configure_grid(self):
        for i in range(9):
            self.root.grid_rowconfigure(i, weight=1)
            self.root.grid_columnconfigure(i, weight=1)
        self.root.grid_rowconfigure(10, weight=1)
        self.root.grid_rowconfigure(11, weight=1)

    def create_difficulty_menu(self):
        menu = tk.Menu(self.root)
        self.root.config(menu=menu)
        difficulty_menu = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label="Difficulty", menu=difficulty_menu)
        difficulty_menu.add_radiobutton(label="Easy", variable=self.difficulty, command=self.change_difficulty)
        difficulty_menu.add_radiobutton(label="Medium", variable=self.difficulty, command=self.change_difficulty)
        difficulty_menu.add_radiobutton(label="Hard", variable=self.difficulty, command=self.change_difficulty)

    def change_difficulty(self):
        self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
        self.update_grid()

    def record_move(self, event):
        widget = event.widget
        for i in range(9):
            for j in range(9):
                if self.entries[i][j] == widget:
                    previous_value = self.entries[i][j].get()
                    if previous_value == '':
                        previous_value = None
                    self.moves.append((i, j, previous_value))
                    return

    def undo(self):
        if self.moves:
            i, j, value = self.moves.pop()
            self.entries[i][j].config(state='normal')
            self.entries[i][j].delete(0, tk.END)
            if value is not None:
                self.entries[i][j].insert(0, value)
            else:
                self.entries[i][j].config(bg='white')

    def solve(self):
        if not self.game.solve():
            messagebox.showerror("Error", "No solution exists!")
        else:
            for i in range(9):
                for j in range(9):
                    self.entries[i][j].delete(0, tk.END)
                    self.entries[i][j].insert(0, str(self.game.board[i][j]))
            messagebox.showinfo("Solved", "The puzzle is solved!")
            self.stop_timer()
            self.shuffle_board()
            solving_time = time.time() - self.start_time
            self.update_best_time(solving_time)

    def clear(self):
        for i in range(9):
            for j in range(9):
                if self.game.original_board[i][j] == 0:
                    self.entries[i][j].delete(0, tk.END)
        self.moves.clear()
        self.start_time = time.time()
        self.update_timer()

    def hint(self):
        empty_cells = [(i, j) for i in range(9) for j in range(9) if self.entries[i][j].get() == ""]
        if empty_cells:
            i, j = random.choice(empty_cells)
            previous_value = self.entries[i][j].get()
            self.entries[i][j].insert(0, str(self.game.solution_board[i][j]))
            self.entries[i][j].config(state='disabled', disabledbackground='#D3D3D3')
            self.moves.append((i, j, previous_value))
        
            if not any(self.entries[i][j].get() == "" for i in range(9) for j in range(9)):
                if self.game.check_board():
                    messagebox.showinfo("Congratulations", "You solved the puzzle!")
                else:
                    messagebox.showinfo("Incorrect", "The puzzle is not solved correctly.")
                self.shuffle_board()
        else:
            messagebox.showinfo("No Empty Spaces", "All spaces are filled!")

    def generate_sudoku(self, difficulty):
        # Generate a complete, valid Sudoku board
        board = [[0]*9 for _ in range(9)]
        self.solve_from_empty(board)

        # Remove some numbers to create the puzzle based on difficulty
        if difficulty == "Easy":
            remove_count = 40
        elif difficulty == "Medium":
            remove_count = 50
        else:  # Hard
            remove_count = 60

        for _ in range(remove_count):
            i = random.randint(0, 8)
            j = random.randint(0, 8)
            while board[i][j] == 0:
                i = random.randint(0, 8)
                j = random.randint(0, 8)
            board[i][j] = 0

        self.shuffle_board_numbers(board)
        self.randomize_board(board)
        return board

    def solve_from_empty(self, board):
        temp_game = SudokuGame(board)
        temp_game.solve()
        for i in range(9):
            for j in range(9):
                board[i][j] = temp_game.board[i][j]

    def shuffle_board_numbers(self, board):
        numbers = list(range(1, 10))
        random.shuffle(numbers)
        number_map = {i: numbers[i - 1] for i in range(1, 10)}
        for i in range(9):
            for j in range(9):
                if board[i][j] != 0:
                    board[i][j] = number_map[board[i][j]]

    def randomize_board(self, board):
        # Perform random row swaps within blocks
        for _ in range(10):
            block_row = random.randint(0, 2) * 3
            row1 = block_row + random.randint(0, 2)
            row2 = block_row + random.randint(0, 2)
            if row1 != row2:
                board[row1], board[row2] = board[row2], board[row1]

        # Perform random column swaps within blocks
        for _ in range(10):
            block_col = random.randint(0, 2) * 3
            col1 = block_col + random.randint(0, 2)
            col2 = block_col + random.randint(0, 2)
            if col1 != col2:
                for row in board:
                    row[col1], row[col2] = row[col2], row[col1]

        # Perform random block swaps (row and column)
        for _ in range(10):
            block1 = random.randint(0, 2)
            block2 = random.randint(0, 2)
            if block1 != block2:
                for i in range(3):
                    board[block1 * 3 + i], board[block2 * 3 + i] = board[block2 * 3 + i], board[block1 * 3 + i]

        for _ in range(10):
            block1 = random.randint(0, 2)
            block2 = random.randint(0, 2)
            if block1 != block2:
                for row in board:
                    for i in range(3):
                        row[block1 * 3 + i], row[block2 * 3 + i] = row[block2 * 3 + i], row[block1 * 3 + i]

    def shuffle_board(self):
        self.game = SudokuGame(self.generate_sudoku(self.difficulty.get()))
        self.moves.clear()
        self.start_time = time.time()
        self.update_grid()

    def update_grid(self):
        for i in range(9):
            for j in range(9):
                self.entries[i][j].config(state='normal')
                self.entries[i][j].delete(0, tk.END)
                if self.game.original_board[i][j] != 0:
                    self.entries[i][j].insert(0, str(self.game.original_board[i][j]))
                    self.entries[i][j].config(state='disabled', disabledbackground='#D3D3D3')
                else:
                    self.entries[i][j].config(bg='white')

    def update_timer(self):
        elapsed_time = time.time() - self.start_time
        minutes, seconds = divmod(int(elapsed_time), 60)
        self.timer_label.config(text=f"Time: {minutes:02}:{seconds:02}")
        self.timer = self.root.after(1000, self.update_timer)

    def stop_timer(self):
        self.root.after_cancel(self.timer)

    def on_resize(self, event):
        self.draw_grid_lines()

    def load_best_time(self):
        if os.path.exists("best_time.txt"):
            with open("best_time.txt", "r") as file:
                best_time = float(file.read())
            return best_time
        else:
            return None

    def update_best_time(self, solving_time):
        if self.best_time is None or solving_time < self.best_time:
            self.best_time = solving_time
            with open("best_time.txt", "w") as file:
                file.write(str(solving_time))

    def show_history(self):
        if self.best_time is not None:
            messagebox.showinfo("Best Time", f"The best solved time is: {self.format_time(self.best_time)}")
        else:
            messagebox.showinfo("No History", "No best time recorded yet.")

    def format_time(self, time_seconds):
        minutes, seconds = divmod(int(time_seconds), 60)
        return f"{minutes:02}:{seconds:02}"

if __name__ == "__main__":
    root = tk.Tk()
    game = SudokuGUI(root)
    root.mainloop()


